package com.example.administrator.campuscompass;

import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.INTERNET;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;
import static android.hardware.Sensor.TYPE_ORIENTATION;
import static android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_GPS = 1001;
    private Camera mCamera;
    private CameraPreview mPreview;
    private FrameLayout preview;

    private SensorManager sensorManager;
    private Sensor sensorOrientation;
    private SensorEventListener eventListenerOrientation;

    private Button btn_azimuth, tv_roll, tv_pitch;
    private Button btn_lat, btn_lon;
    private TextView tv_data;
    private Button tv_thita_factor;

    private LocationManager locationManager;
    private LocationListener locationListener;

    private DatabaseReference mReference;

    private List<PointInterest> pointInterestList;

    private double latitude1 = 0, longitude1 = 0;

    private float azimuth_factor = 0;
    private float radius_factor = (float) 0.833;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null)
            actionBar.hide();
        getWindow().setFlags(FLAG_FULLSCREEN, FLAG_FULLSCREEN);

        //FindViewByIds
        preview = findViewById(R.id.camera_preview);
        tv_pitch = findViewById(R.id.tv_pitch);
        tv_roll = findViewById(R.id.tv_roll);
        tv_data = findViewById(R.id.tv_disp_data);
        btn_azimuth = findViewById(R.id.button);
        btn_lat = findViewById(R.id.bnt_lat);
        btn_lon = findViewById(R.id.bnt_lon);
        tv_thita_factor = findViewById(R.id.tv_thita_factor);

        pointInterestList = new ArrayList<>();

        mReference = FirebaseDatabase.getInstance().getReference("Campus Navigation").child("VIT").child("Points of Interest");
        mReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    if (dataSnapshot1 != null) {

                        PointInterest pointInterest = new PointInterest();

                        pointInterest.setLat(dataSnapshot1.child("lat").getValue().toString());
                        pointInterest.setLon(dataSnapshot1.child("lon").getValue().toString());
                        pointInterest.setName(dataSnapshot1.child("name").getValue().toString());

                        pointInterestList.add(pointInterest);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        // Create our Preview view and set it as the content of our activity.
        mCamera = getCameraInstance();
        mPreview = new CameraPreview(this, mCamera);
        preview.addView(mPreview);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            sensorOrientation = sensorManager.getDefaultSensor(TYPE_ORIENTATION);
        }

        eventListenerOrientation = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {

                float[] values = event.values;

                float azimuth = values[0] - azimuth_factor;
                float pitch = values[1];
                float roll = values[2];

                btn_azimuth.setText("Azimuth: " + String.format("%.2f", azimuth));
                tv_pitch.setText("Pitch: " + String.format("%.2f", pitch));
                tv_roll.setText("Roll: " + String.format("%.2f", roll));

                StringBuilder stringBuilder = new StringBuilder();

                for (PointInterest poi : pointInterestList) {

                    Double lat = Double.parseDouble(poi.getLat());
                    Double lon = Double.parseDouble(poi.getLon());

                    //Location Results
                    float[] results = new float[3];
                    Location.distanceBetween(latitude1, longitude1, lat, lon, results);

                    double x1 = latitude1, y1 = longitude1;
                    double x2 = lat, y2 = lon;

                    double slope = ( y2 - y1 ) / ( x2 - x1 );

                    tv_thita_factor.setText("Thita: " + String.format("%.2f", slope));

                    if (roll > 50) {
                        String data = poi.getName() + " Slope: " + String.format("%.2f", slope) + "\n";
                        stringBuilder.append(data);
                    }
                }
                tv_data.setText(stringBuilder.toString());

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
        sensorManager.registerListener(eventListenerOrientation, sensorOrientation, SensorManager.SENSOR_DELAY_NORMAL);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                latitude1 = location.getLatitude();
                longitude1 = location.getLongitude();

                String longitude = "Lon: " + String.valueOf(latitude1);
                String latitude = "Lat: "+ String.valueOf(longitude1);

                btn_lat.setText(latitude);
                btn_lon.setText(longitude);

            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION)
                != PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, ACCESS_COARSE_LOCATION)
                != PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{
                        INTERNET
                        , ACCESS_COARSE_LOCATION
                        , ACCESS_FINE_LOCATION
                }, REQ_GPS);
            }
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);

    }

    public static Camera getCameraInstance() {
        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
            Camera.Parameters params = c.getParameters();
            params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            c.setParameters(params);
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
        }

        return c; // returns null if camera is unavailable
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQ_GPS:
                if (grantResults.length > 0 && grantResults[0] == PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(this, "Please grant permission", Toast.LENGTH_SHORT).show();
        }
    }

}